public class CorrectAnswer extends HackCell{

    public CorrectAnswer(int numVer) {
        super(numVer);
    }

    public String toString(){
        return numVer + " YOU WIN"; //if the CorrectAnswer card type is clicked, the toString() method will return the winning message concatenated with the winning number.
    }
}
