public class UnluckyCell extends HackCell{

    public UnluckyCell(int numVer) {
        super(numVer);
    }

    private String failMessage = "GAME OVER";

    public String toString(){ //overridden toString() method returns the fail message if the UnluckyCell card type is clicked.
        return failMessage;
    }
}
