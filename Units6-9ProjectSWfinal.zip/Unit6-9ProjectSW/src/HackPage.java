import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class HackPage implements ActionListener {
    Hack2DArray h = new Hack2DArray(3, 6); //creates new Hack2DArray with set rows and cols.


    ArrayList<JButton> jbArrayList = new ArrayList<JButton>(); //creates an ArrayList of JButtons to put the cards into (the cards extend JButton)

    JFrame frame = new JFrame("Let's see how lucky you are!");
    JPanel panel = new JPanel();
    int correctAnswer = h.getCorrectAnswer(); //sets the correct answer in this class.

    public HackPage() { //GUI visual setup
        Start.setScore(100);
        frame.setSize(1280, 720);
        frame.setVisible(true);
        frame.setResizable(false);

        panel.setBounds(0, 50, 1000, 600);
        panel.setLayout(new GridLayout(h.getRows(), h.getCols(), 0, 0));
        panel.setVisible(true);
        frame.add(panel);
        setUpGrid(h);

        JOptionPane.showMessageDialog(null, "Your lucky number is: " + correctAnswer, "Alert", JOptionPane.PLAIN_MESSAGE);
    }

    public void setUpGrid(Hack2DArray c) { //Hack2DArray is passed in as a parameter for setting up the Grid using GridLayout
        for (int i = 0; i < c.getCell2DArray().length; i++) { //parses every element in the 2D array of HackCell objects and adds them as JButtons to the screen.
            for (int j = 0; j < c.getCell2DArray()[0].length; j++) {
                JButton jb = c.getCell2DArray()[i][j]; //making the HackCell class inherit JButton is crucial for the methods here!
                jb.setForeground(Color.GREEN);
                jb.setBackground(Color.BLACK);
                jb.setFont(new Font("Courier New", 0, 35));
                jb.setBorder(BorderFactory.createEmptyBorder());
                jb.addActionListener(this);
                jb.setText("???");
                panel.add(jb);
                jbArrayList.add(jb);
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) { //Whenever a card is clicked, ActionListener checks the type of the card and responds accordingly.
        Object o = e.getSource();
        if (o instanceof CorrectAnswer){ //if the button clicked is the correct answer, the player wins.
            Start.addWins();
            Start.deduct(-30); //if the player wins they get 30 pts
            System.out.println("Score added 30");
            System.out.println(Start.getScore());
            ((JButton)o).setText(((CorrectAnswer)o).toString()); //sets the button text to a winning message. (Here I am able to use JButton methods to set the text of the cards, another reason why I made HackCell inherit JButton)
            ((JButton)o).setFont(new Font("Courier New", 0, 15));
            ((JButton)o).setForeground(Color.YELLOW);
            JOptionPane.showMessageDialog(null, "You guessed the lucky number, you win! Close the window to continue.", "Congratulations!", JOptionPane.PLAIN_MESSAGE);
            for (JButton j : jbArrayList){
                j.setEnabled(false); //all the JButtons on the screen are disabled after the game is won.
            }
            Start.addScoreToList(Start.getScore());
        }
        else if (o instanceof LuckyCell){ //if the card clicked is the lucky cell, the position of the answer will be revealed.
            Start.deduct(-40);
            System.out.println("Score added 40");
            System.out.println(Start.getScore());
            ((JButton)o).setText(((LuckyCell)o).getCords(h));
            JOptionPane.showMessageDialog(null, "You got lucky! The position of the answer is displayed in r-c order!", "Alert", JOptionPane.PLAIN_MESSAGE);

        }
        else if (o instanceof UnluckyCell){ //if the button clicked is the unlucky cell, the game ends.
            Start.deduct(50);
            System.out.println("Score deducted 50");
            System.out.println(Start.getScore());
            Start.addLosses();
            ((JButton)o).setText(((UnluckyCell)o).toString());
            ((JButton)o).setFont(new Font("Courier New", 0, 15));
            ((JButton)o).setForeground(Color.RED);
            JOptionPane.showMessageDialog(null, "You're really unlucky today! You lost! Close the window to continue.", "Today's not your day...", JOptionPane.PLAIN_MESSAGE);
            for (JButton j : jbArrayList){
                j.setEnabled(false);
            }
            Start.addScoreToList(Start.getScore());

        }
        //after all other conditions are checked, if the card clicked is just a regular card, the following executes.
        else if (o instanceof HackCell && !(o instanceof LuckyCell) && !(o instanceof CorrectAnswer) && !(o instanceof UnluckyCell)){ //if the button clicked is a normal cell, the "???" is replaced by the number hidden underneath.
            Start.deduct(5); //5 pts are deducted
            System.out.println("Score deducted 5");
            System.out.println(Start.getScore());
            ((JButton)o).setText(((HackCell)o).toString(true)); //the hidden number on that card is revealed by resetting the text.
        }
    }
}

