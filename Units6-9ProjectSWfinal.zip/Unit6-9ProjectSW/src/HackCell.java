import javax.swing.*;

public class HackCell extends JButton {
    int numVer; //numerical value
    String displayMessage = "???"; //displayed when game first starts and no cards are revealed yet.

    public HackCell(int numVer) {
        this.numVer = numVer;
    }

    public String toString() { //when the game starts, all the cards' display values are set to "???" using this method.
        return displayMessage;
    }
    public String toString(boolean b) { //an overloaded toString method so that if the card is clicked, the text switches from "???" to display the number hidden below.
        return numVer + "";
    }
}
