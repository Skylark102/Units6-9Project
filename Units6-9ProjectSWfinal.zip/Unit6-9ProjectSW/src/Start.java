import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;

public class Start implements ActionListener {
    JFrame frame = new JFrame("Lucky Numbers");
    JTextArea desc = new JTextArea("Welcome to the Lucky Numbers game, how lucky are you?");
    JButton startButton = new JButton("Start");
    JButton scoreButton = new JButton("Scores");
    JButton instructions = new JButton("Instructions");
    private static int wins;
    private static int losses;
    private static int score = 100; //your score starts at 100 and is deducted each time when you choose the wrong card.
    private static ArrayList<Integer> scores = new ArrayList<Integer>();
    //I made these variables static because they do not pertain to a particular object, but to the game as a whole.

    public Start(){ //GUI visual components
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(new Dimension(1280, 720));
        frame.getContentPane().setBackground(Color.BLACK);
        frame.setResizable(false);
        frame.setVisible(true);

        desc.setFont(new Font("Courier New",Font.PLAIN,25));
        desc.setForeground(Color.GREEN);
        desc.setBackground(Color.BLACK);
        desc.setVisible(true);
        desc.setBounds(220,200,1000,50);
        desc.setEditable(false);
        frame.add(desc);

        startButton.setEnabled(true);
        startButton.setBounds(600, 300, 120, 60);
        startButton.setBackground(Color.BLACK);
        startButton.setForeground(Color.GREEN);
        startButton.addActionListener(this);
        frame.add(startButton);

        scoreButton.setEnabled(true);
        scoreButton.setBounds(600, 370, 120, 60);
        scoreButton.setBackground(Color.BLACK);
        scoreButton.setForeground(Color.GREEN);
        scoreButton.addActionListener(this);
        frame.add(scoreButton);

        instructions.setEnabled(true);
        instructions.setBounds(600, 440, 120, 60);
        instructions.setBackground(Color.BLACK);
        instructions.setForeground(Color.GREEN);
        instructions.addActionListener(this);
        frame.add(instructions);
    }
        @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource() == startButton) { //launches a round of the game.
            setScore(100);
            HackPage h = new HackPage();
        }
        if (e.getSource() == scoreButton) { //check scores
            try { //I used a try-catch here because if the player hasn't played a round yet, all the scores will be null. This would cause an error when displaying the null variables, so that error is caught and a different message is displayed instead.
                JOptionPane.showMessageDialog(null, "Wins: " + wins + "\n" + "Losses: " + losses + "\nHi-score: " + maxScore() + "\nAverage: " + averageScore() + "\n" + luck() , "Scores", JOptionPane.PLAIN_MESSAGE);}
            catch (Exception ex){
                JOptionPane.showMessageDialog(null, "You have no scores right now, play a game to get started.", "Scores", JOptionPane.PLAIN_MESSAGE);
            }
        }
        if (e.getSource() == instructions) { //display instructions
            JOptionPane.showMessageDialog(null, "How to play:\n- When you start a new game, you're given a lucky number which you have to find within the deck of hidden cards.\n- Click on a card to reveal its number. If the card's number matches your lucky number, you win.\n- If you click on an unlucky card, you lose immediately.\n- If you get lucky, you might click on a card that reveals the correct card's position.\n- How lucky you are is determined by a score calculated at the end of each round.", "Instructions", JOptionPane.PLAIN_MESSAGE);
        }
    }


        //Helper methods for dealing with the ArrayList managing player scores
    public static void addScoreToList(int score){
        scores.add(score);
    }

    public static void deduct(int pts){
        score -= pts;
    }

    public static void setScore(int s){
        score = s;
    }
    public static int getScore(){
        return score;
    }
    private static int averageScore(){
        int total = 0;
        for (Integer i : scores){
            total += i;
        }
        return total / scores.size();
    }
    private static String luck(){
        if (averageScore() > 50) return "You have good luck";
        else return "You have bad luck";
    }

    private static int maxScore(){
        return Collections.max(scores);
    }

    public static void addWins(){
        wins++;
    }
    public static int getWins(){
        return wins;
    }
    public static void addLosses(){
        losses++;
    }
    public static int getLosses(){
        return losses;
    }
}

