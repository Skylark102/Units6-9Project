public class Hack2DArray { //data class
    private HackCell[][] cells; //2D array representation of the card deck with each HackCell being a card.
    private int rows;
    private int cols;
    private int correct = (int)(Math.random() * 10000); //randomly generates the Lucky Number from 1-10000;

    public Hack2DArray(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        cells = new HackCell[rows][cols];
        setUpCells();
    }

    public int getCorrectAnswer(){
        return correct;
    }

    public void setUpCells() { //Traverses through the 2D Array created in the constructor and randomly assigns each element a card type based on probability.
        for (int i = 0; i < cells.length; i++) {
            for (int j = 0; j < cells[0].length; j++) {
                double x = Math.random();
                if (x > 0.2) { //there is an 80% chance that the cell generated will be a normal cell with a normal number
                    cells[i][j] = new HackCell((int) (Math.random() * 10000));
                } else if (x <= 0.2 && x > 0.15) {
                    cells[i][j] = new LuckyCell((int) (Math.random() * 10000)); //there is a 5% chance the cell generated will be a lucky cell
                } else {
                    cells[i][j] = new UnluckyCell((int) (Math.random() * 10000)); //there is a 15% chance the cell generated will be an unlucky cell
                }
            }
        }
        cells[(int)(Math.random() * cells.length)][(int)(Math.random() * cells[0].length)] = new CorrectAnswer(correct); //the correct answer is set to a random position in the 2D array.
    }

    //getter methods
    public int getRows(){
        return rows;
    }
    public int getCols(){
        return cols;
    }
    public HackCell[][] getCell2DArray(){
        return cells;
    }
}
