public class LuckyCell extends HackCell{
    public LuckyCell(int numVer) { //calls super constructor to create a LuckyCell object
        super(numVer);
    }

    public String toString(){ //displays the card's value on the screen as "???" when the game starts.
        return displayMessage;
    }

    //if the LuckyCell card type is clicked, this method will find the coordinates of the correct answer and that will be displayed instead of the regular number. This is done in the HackPage's ActionPerformed method.
    public String getCords(Hack2DArray h){
        for (int i = 0; i< h.getCell2DArray().length; i++){
            for (int j = 0; j< h.getCell2DArray()[0].length; j++){
                if (h.getCell2DArray()[i][j] instanceof CorrectAnswer) return "(" + (i + 1) + ", " + (j + 1) + ")";
            }
        }
        return "";
    }





}
